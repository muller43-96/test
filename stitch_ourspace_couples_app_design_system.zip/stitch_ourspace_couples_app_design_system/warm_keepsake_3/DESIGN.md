---
name: Warm Keepsake
colors:
  surface: '#fbf9f6'
  surface-dim: '#F5F1EB'
  surface-bright: '#FFFFFF'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f3f0'
  surface-container: '#F5F1EB'
  surface-container-high: '#EFE7DE'
  surface-container-highest: '#E5DED5'
  on-surface: '#2C292E'
  on-surface-variant: '#7E7883'
  inverse-surface: '#30312f'
  inverse-on-surface: '#f2f0ed'
  outline: '#EFE7DE'
  outline-variant: '#DFD8CE'
  surface-tint: '#a13e37'
  primary: '#9e3b34'
  on-primary: '#ffffff'
  primary-container: '#FDF0EE'
  on-primary-container: '#D35E54'
  inverse-primary: '#ffb4ab'
  secondary: '#58569e'
  on-secondary: '#ffffff'
  secondary-container: '#F1F0FA'
  on-secondary-container: '#5B58A6'
  tertiary: '#286656'
  on-tertiary: '#ffffff'
  tertiary-container: '#EEF6F4'
  on-tertiary-container: '#3D7866'
  error: '#BA1A1A'
  on-error: '#ffffff'
  error-container: '#FFDAD6'
  on-error-container: '#410002'
  primary-fixed: '#ffdad6'
  primary-fixed-dim: '#ffb4ab'
  on-primary-fixed: '#410002'
  on-primary-fixed-variant: '#822622'
  secondary-fixed: '#e2dfff'
  secondary-fixed-dim: '#c3c0ff'
  on-secondary-fixed: '#130d58'
  on-secondary-fixed-variant: '#403e84'
  tertiary-fixed: '#b0efdb'
  tertiary-fixed-dim: '#95d3bf'
  on-tertiary-fixed: '#002019'
  on-tertiary-fixed-variant: '#0b5041'
  background: '#fbf9f6'
  on-background: '#1b1c1a'
  surface-variant: '#e4e2df'
  soft-peach: '#F9B299'
  peach-container: '#FEF4F0'
  placeholder-text: '#A8A2AC'
typography:
  display-lg:
    fontFamily: Playfair Display
    fontSize: 40px
    fontWeight: '600'
    lineHeight: 48px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 30px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-md:
    fontFamily: Playfair Display
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
  headline-sm:
    fontFamily: Playfair Display
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  title-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 10px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-tablet: 1.25rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-tablet: 1.5rem
  margin-desktop: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

---
name: Warm Keepsake
colors:
  surface: '#FAF8F5'
  surface-dim: '#F5F1EB'
  surface-bright: '#FFFFFF'
  surface-container-lowest: '#FFFFFF'
  surface-container-low: '#FAF8F5'
  surface-container: '#F5F1EB'
  surface-container-high: '#EFE7DE'
  surface-container-highest: '#E5DED5'
  on-surface: '#2C292E'
  on-surface-variant: '#7E7883'
  outline: '#EFE7DE'
  outline-variant: '#DFD8CE'
  primary: '#E06D63'
  on-primary: '#FFFFFF'
  primary-container: '#FDF0EE'
  on-primary-container: '#D35E54'
  secondary: '#8E8CD8'
  on-secondary: '#FFFFFF'
  secondary-container: '#F1F0FA'
  on-secondary-container: '#5B58A6'
  tertiary: '#78B5A2'
  on-tertiary: '#FFFFFF'
  tertiary-container: '#EEF6F4'
  on-tertiary-container: '#3D7866'
  error: '#BA1A1A'
  on-error: '#FFFFFF'
  error-container: '#FFDAD6'
  on-error-container: '#410002'
  background: '#FAF8F5'
  on-background: '#2C292E'
typography:
  font-family-display: 'Playfair Display', serif
  font-family-body: 'Plus Jakarta Sans', sans-serif
roundness: ROUND_FULL
---

# Warm Keepsake — Canonical Design System for OurSpace

OurSpace is an intimate, private digital world exclusively for two people, crafted primarily for long-distance partners.

## Core Brand Identity & Palette
- **Warm Ivory (`#FAF8F5`)**: Ambient background canvas across all views.
- **Muted Sand (`#F5F1EB`)**: Subtle secondary surfaces, card backgrounds, and chips.
- **Warm White (`#FFFFFF`)**: Card surfaces, active elevated sheets, and popovers.
- **Primary Coral Rose (`#E06D63`)**: Signature romantic accent, buttons, active highlights.
- **Deep Coral (`#D35E54`)**: Pressed and active states for primary actions.
- **Primary Container (`#FDF0EE`)**: Soft romantic badge and highlight backgrounds.
- **Gentle Lavender (`#8E8CD8`)**: Partner Liam's signature accent & co-presence elements.
- **Lavender Container (`#F1F0FA`)**: Partner secondary badge backgrounds.
- **Soft Mint (`#78B5A2`)**: Bilateral connection, synchronized states, and presence.
- **Mint Container (`#EEF6F4`)**: Soft badge for active synchronization.
- **Soft Peach (`#F9B299`)**: Warm keepsake details, celebrations, and countdown highlights.
- **Peach Container (`#FEF4F0`)**: Countdown container and milestone banners.
- **Deep Charcoal (`#2C292E`)**: High-contrast, accessible primary typography.
- **Muted Gray (`#7E7883`)**: Secondary text, subtle metadata, and inactive icons.
- **Light Gray (`#A8A2AC`)**: Subtle borders, placeholder copy.
- **Subtle Border (`#EFE7DE`)**: Card borders and divider rules.

## Typography
- **Headings & Editorial Keepsakes**: `Playfair Display` (font-serif).
- **Interface & System Labels**: `Plus Jakarta Sans` (font-sans).

## Product Rules
- **Global Navigation**: Fixed 5 tabs (`Home`, `Chat`, `Games`, `Music`, `Memories`).
- **Create**: Floating action button opening contextual sheet (Draw, Note, Photo, Surprise).
- **Music**: YouTube embedded player (min 200x200), realistic sync status, no audio-only extraction claims.
- **Sensory & Privacy**: In-app animations & emoji reactions (no unsupported remote hardware haptic promises). Accurate privacy messaging ("Your private space, shared with one person").
- **Drawing**: Solo drawing by default with Preview & Send. Live Duo marked as Coming Soon.
