---
name: Warm Keepsake
colors:
  surface: '#fbf9f6'
  surface-dim: '#F5F1EB'
  surface-bright: '#FFFFFF'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#FAF6F2'
  surface-container: '#F5EFE8'
  surface-container-high: '#EDE5DC'
  surface-container-highest: '#E4DBD0'
  on-surface: '#1b1c1a'
  on-surface-variant: '#564240'
  inverse-surface: '#30312f'
  inverse-on-surface: '#f2f0ed'
  outline: '#89716f'
  outline-variant: '#ddc0bd'
  surface-tint: '#a13e37'
  primary: '#9e3b34'
  on-primary: '#ffffff'
  primary-container: '#FDF0EE'
  on-primary-container: '#fffbff'
  inverse-primary: '#ffb4ab'
  secondary: '#58569e'
  on-secondary: '#ffffff'
  secondary-container: '#F1F0FA'
  on-secondary-container: '#413f85'
  tertiary: '#286656'
  on-tertiary: '#ffffff'
  tertiary-container: '#437f6e'
  on-tertiary-container: '#f4fff9'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdad6'
  primary-fixed-dim: '#ffb4ab'
  on-primary-fixed: '#410002'
  on-primary-fixed-variant: '#822622'
  secondary-fixed: '#e2dfff'
  secondary-fixed-dim: '#c3c0ff'
  on-secondary-fixed: '#130d58'
  on-secondary-fixed-variant: '#403e84'
  tertiary-fixed: '#b0efdb'
  tertiary-fixed-dim: '#95d3bf'
  on-tertiary-fixed: '#002019'
  on-tertiary-fixed-variant: '#0b5041'
  background: '#fbf9f6'
  on-background: '#1b1c1a'
  surface-variant: '#e4e2df'
  surface-canvas: '#FAF8F5'
  primary-deep: '#D35E54'
  accent-mint: '#78B5A2'
  accent-mint-container: '#EEF6F4'
  accent-peach: '#F9B299'
  accent-peach-container: '#FEF4F0'
  text-primary: '#2C292E'
  text-secondary: '#7E7883'
  text-tertiary: '#A8A2AC'
  border-subtle: '#EFE7DE'
typography:
  headline-xl:
    fontFamily: Playfair Display
    fontSize: 40px
    fontWeight: '600'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 26px
    fontWeight: '600'
    lineHeight: 34px
  headline-md:
    fontFamily: Playfair Display
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: Playfair Display
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 28px
  title-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '700'
    lineHeight: 26px
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-italic:
    fontFamily: Playfair Display
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.02em
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-mobile: 0.75rem
  margin: 1.5rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

# DESIGN SYSTEM: Warm Keepsake (Canonical)
A private digital world exclusively for two people, crafted for long-distance couples.
Tagline: "A little world for two, no matter how far apart."

## 1. Visual Personality & Emotional Tone
- **Atmosphere**: Warm, intimate, editorial, modern, keepsake scrapbook feel with tactile paper details.
- **Balance**: Equally romantic and playful, appealing symmetrically to both partners.
- **Craft**: Subtle shadows, generous whitespace, rounded pill cards, delicate borders, authentic typography.

## 2. Canonical Color Palette
```yaml
colors:
  surface: '#FAF8F5'                  # Warm Ivory canvas background
  surface-dim: '#F5F1EB'              # Muted Sand secondary surface
  surface-bright: '#FFFFFF'           # Crisp Warm White card surface
  surface-container-lowest: '#FFFFFF'
  surface-container-low: '#FAF6F2'
  surface-container: '#F5EFE8'
  surface-container-high: '#EDE5DC'
  surface-container-highest: '#E4DBD0'
  
  primary: '#E06D63'                  # Primary Coral Rose
  primary-deep: '#D35E54'             # Deep Coral (active/hover states)
  primary-container: '#FDF0EE'        # Coral Rose tint for tags/highlights
  on-primary: '#FFFFFF'
  
  secondary: '#8E8CD8'                # Gentle Lavender (partner Liam accent)
  secondary-container: '#F1F0FA'      # Soft lavender wash
  on-secondary: '#FFFFFF'
  
  accent-mint: '#78B5A2'              # Soft Mint (sync, live presence, completed)
  accent-mint-container: '#EEF6F4'
  
  accent-peach: '#F9B299'             # Soft Peach (warm moments, countdowns)
  accent-peach-container: '#FEF4F0'
  
  text-primary: '#2C292E'             # Deep Charcoal
  text-secondary: '#7E7883'           # Muted Gray
  text-tertiary: '#A8A2AC'            # Light Gray
  
  border-subtle: '#EFE7DE'            # Delicate divider line
  border-focus: '#E06D63'
```

## 3. Typography
- **Headings & Moments**: `Playfair Display`, serif, italic accents for quotes/notes.
- **Interface & Content**: `Plus Jakarta Sans`, sans-serif, weight 400/500/600/700.

## 4. Global Navigation Standards
- **5 Core Tabs**: Home (`/home`), Chat (`/chat`), Games (`/games`), Music (`/music`), Memories (`/memories`).
- **Create Action**: Floating Action Button (FAB) or contextual quick-trigger launching the Create Action Sheet (`Draw something`, `Write a note`, `Share a photo`, `Send a surprise`). Never occupies a permanent bottom navigation tab slot.

## 5. Standardized Fictional Couple
- **Partner 1**: Maya (NYC, Eastern Time).
- **Partner 2**: Liam (London, GMT/BST, 5 hours ahead).
- Consistent relative timestamps: `Just now`, `5m ago`, `Yesterday, 11:42 PM`.
