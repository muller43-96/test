---
name: Warm Keepsake
colors:
  surface: '#fef7fe'
  surface-dim: '#dfd8df'
  surface-bright: '#fef7fe'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f9f1f8'
  surface-container: '#f3ecf2'
  surface-container-high: '#ede6ed'
  surface-container-highest: '#e7e0e7'
  on-surface: '#1d1b1f'
  on-surface-variant: '#564240'
  inverse-surface: '#322f34'
  inverse-on-surface: '#f6eff5'
  outline: '#89716f'
  outline-variant: '#ddc0bd'
  surface-tint: '#a13e37'
  primary: '#9e3b34'
  on-primary: '#ffffff'
  primary-container: '#be534a'
  on-primary-container: '#fffbff'
  inverse-primary: '#ffb4ab'
  secondary: '#58569e'
  on-secondary: '#ffffff'
  secondary-container: '#b0aefd'
  on-secondary-container: '#413f85'
  tertiary: '#286656'
  on-tertiary: '#ffffff'
  tertiary-container: '#437f6e'
  on-tertiary-container: '#f4fff9'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdad6'
  primary-fixed-dim: '#ffb4ab'
  on-primary-fixed: '#410002'
  on-primary-fixed-variant: '#822622'
  secondary-fixed: '#e2dfff'
  secondary-fixed-dim: '#c3c0ff'
  on-secondary-fixed: '#130d58'
  on-secondary-fixed-variant: '#403e84'
  tertiary-fixed: '#b0efdb'
  tertiary-fixed-dim: '#95d3bf'
  on-tertiary-fixed: '#002019'
  on-tertiary-fixed-variant: '#0b5041'
  background: '#fef7fe'
  on-background: '#1d1b1f'
  surface-variant: '#e7e0e7'
typography:
  display-lg:
    fontFamily: Playfair Display
    fontSize: 48px
    fontWeight: '600'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 36px
    fontWeight: '600'
    lineHeight: 44px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Playfair Display
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.03em
  quote-accent:
    fontFamily: Playfair Display
    fontSize: 20px
    fontWeight: '400'
    lineHeight: 30px
    letterSpacing: 0em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-tablet: 1.5rem
  margin-desktop: 2.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

The design system embodies intimacy, tactile presence, and enduring warmth. Designed for couples navigating distance, it frames moments of connection as cherished artifacts rather than ephemeral notifications. The emotional goal is to evoke the comfort of a shared living room and the deliberate care of a private scrapbook—soft, grounded, romantic, yet structured with modern restraint.

The aesthetic fuses modern minimalism with subtle tactile craft: generous warm negative space, soft structural cards reminiscent of heavyweight linen paper, delicate tone-on-tone separations, and intentional typography that balances utilitarian clarity with poetic intimacy. Interactions emphasize tenderness and pause, avoiding jarring transitions or hyperactive visual cues.

## Colors

The palette balances warm earthen rose, nostalgic lavender, and grounding organic tones against a comforting, low-strain canvas:

- **Canvas & Surfaces**: The default foundation is Warm Ivory (`#FAF8F5`), shifting to Muted Sand (`#F5F1EB`) for recessed zones and canvas structure. High-priority interactive cards use pure Warm White (`#FFFFFF`).
- **Primary Brand (Coral Rose - `#E06D63`)**: Represents immediate connection, live presence, and primary calls to action. Softened tint (`#E87A6E`) serves hover and gentle highlights.
- **Secondary (Gentle Lavender - `#8E8CD8`)**: Signals reflection, quiet states, evening rituals, and passive presence. Deepened variant (`#9B86D4`) acts as a soft counterpart to Coral Rose.
- **Tertiary Accent (Soft Mint - `#78B5A2`)**: Denotes shared growth, timeline milestones, sync status, and peaceful affirmations.
- **Complementary Warmth (Soft Peach - `#F9B299`)**: Used sparingly for badge backgrounds, warm reaction indicators, and delicate photo frame highlights.
- **Text & Hierarchy**: Primary copy uses Deep Charcoal (`#2C292E`) for high-legibility warmth without the harshness of pitch black. Secondary details, timestamps, and metadata employ Warm Muted Gray (`#7E7883`).

## Typography

Typography establishes an intimate editorial cadence:

- **Playfair Display**: Reserved for personal reflections, date milestones, page anchors, and scrapbook note headlines. It brings poetic warmth and deliberate, classic cadence to shared thoughts. It must never be used for utilitarian UI elements or dense data labels.
- **Plus Jakarta Sans**: Handles operational communication, continuous chat streams, timeline readouts, and interactive controls. Its open apertures and balanced geometry preserve crisp legibility across varying mobile pixel densities.
- **Quote Accent**: A specialized role for hand-penned love notes, shared quotes, and milestone memories, set in italic or natural weight to create a journal-like atmosphere.

## Layout & Spacing

The layout is built on a responsive fluid grid that prioritizes breathing room, personal pacing, and vertical continuity:

- **Mobile (< 768px)**: 4-column layout with `1rem` margins and `1rem` gutters. Content flows in a single primary feed with stacked scrapbook cards, edge-to-edge photo ribbons with internal padding, and anchored bottom navigation.
- **Tablet (768px - 1024px)**: 8-column layout with `1.5rem` margins and gutters. Adapts to a dual-pane presentation: one pane for ongoing shared status (music, timezones, battery, countdowns) and one for scrapbook feeds and correspondence.
- **Desktop (> 1024px)**: 12-column layout maxing out at `1200px` content width with `2.5rem` margins. The viewport centers as a tranquil shared desk, framing communication feeds, mood boards, and media vaults symmetrically.
- **Rhythm**: Element spacing relies strictly on multiples of `0.25rem` (4px baseline), ensuring consistent alignment between intimate snippets of text and photo artifacts.

## Elevation & Depth

Visual hierarchy uses tactile physical metaphors rather than synthetic electronic elevation:

- **Flat Canvas**: Base layer (`#FAF8F5`) acts as the desktop or journal surface.
- **Paper Surface (Cards & Feeds)**: Set in `#FFFFFF` with a dual-step warm drop shadow: `0 2px 4px rgba(44, 41, 46, 0.02), 0 8px 24px rgba(224, 109, 99, 0.06)`. This provides a gentle, ambient lift as if sheets of heavy cardstock are resting lightly on the surface.
- **Borders & Edges**: Elements are bound by delicate, low-contrast ghost borders: `1px solid rgba(126, 120, 131, 0.12)`. This maintains structural containment without breaking the warm, organic mood.
- **Floating Overlays (Modals & Bottom Sheets)**: Use higher diffused dispersion: `0 16px 40px rgba(44, 41, 46, 0.08)` paired with an ivory-tinted backdrop blur (`rgba(250, 248, 245, 0.8)` with `backdrop-filter: blur(8px)`).
- **Physical Press**: On active interaction, cards and buttons compress downward, flattening the shadow to `0 1px 2px rgba(44, 41, 46, 0.04)` and shifting down 1px to mimic pressing paper into a mat.

## Shapes

The shape system adopts a softened, rounded geometry (Level 2: `0.5rem` / `8px` base, `1rem` / `16px` for cards, and `1.5rem` / `24px` for structural sheet containers). 

This curvature imparts friendliness and tactile comfort, avoiding both clinical square edges and overly bulbous shapes. Circular silhouettes (`50%` / pill forms) are reserved exclusively for avatars, reaction tags, status rings, and prominent standalone action buttons.

## Components

### Buttons
- **Primary**: Solid Coral Rose (`#E06D63`) with white text, `0.75rem` vertical and `1.25rem` horizontal padding, `1rem` border radius. Gentle warm shadow on rest; darkens subtly to `#D35E54` on press.
- **Secondary**: Gentle Lavender background with 12% opacity (`rgba(142, 140, 216, 0.12)`), Lavender text (`#8E8CD8`), no shadow, 1px border (`rgba(142, 140, 216, 0.25)`).
- **Tertiary / Ghost**: Deep charcoal text with transparent background; reveals Muted Sand (`#F5F1EB`) fill on hover.

### Cards & Keepsake Tiles
- Crisp `#FFFFFF` surface enclosed by a delicate 1px border (`rgba(126, 120, 131, 0.12)`), radius of `1rem`, and ambient coral-tinted shadow.
- Keepsake memory cards can incorporate subtle paper-pin or tape accents in Peach (`#F9B299`) or Mint (`#78B5A2`) at card headers for romantic scrapbooking flair.

### Input Fields
- Built on `#FFFFFF` backgrounds with an inset feel: `1px solid rgba(126, 120, 131, 0.2)`. 
- Height of `48px`, font size of `16px` (preventing iOS auto-zoom), with rounded corners of `0.75rem`.
- Focus state softens the border to Coral Rose (`#E06D63`) with a diffuse outer glow: `0 0 0 3px rgba(224, 109, 99, 0.15)`.

### Chips & Mood Badges
- Pill-shaped (`rounded-full`), `0.25rem` vertical and `0.75rem` horizontal padding.
- Status chips (e.g., "Sleeping", "In Transit", "Thinking of You") use 15% tinted backgrounds of Mint, Lavender, or Peach with matching high-chroma text and small 6px solid dot indicators.

### Checkboxes & Radio Controls
- Circular and smooth rounded-square geometries (`0.375rem` radius for checkboxes).
- Unchecked: 1.5px border of Warm Muted Gray (`#7E7883`) over a transparent background.
- Checked: Solid Coral Rose fill featuring a crisp white interior checkmark or center dot, accompanied by a quick, organic spring transition.

### Lists & Timeline Dividers
- Lists sit flat on Ivory backgrounds with cards or borderless rows separated by soft hairline rules (`1px solid rgba(126, 120, 131, 0.08)`).
- Timeline threads feature a continuous vertical dotted line in Lavender Tint (`rgba(142, 140, 216, 0.3)`) anchored by soft node badges representing letters, voice notes, and countdown dates.

### Specialized Keepsake Components
- **Presence Orb**: A dual-ring indicator displaying both partners' states, gently breathing with CSS keyframe pulses tinted in primary and secondary hues.
- **Audio Note Capsule**: Lavender-tinted horizontal pill enclosing a dynamic audio waveform, play toggle, and Playfair Display timestamp.